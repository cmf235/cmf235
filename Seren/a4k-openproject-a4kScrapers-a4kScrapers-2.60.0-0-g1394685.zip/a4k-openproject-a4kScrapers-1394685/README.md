# a4kScrapers

Provider for [Seren](https://github.com/nixgates/plugin.video.seren) and [a4kStreaming](https://github.com/a4k-openproject/a4kStreaming) 
<br/>
Latest version: [bit.ly/a4kScrapers](https://bit.ly/a4kScrapers)

**Status**  
AppVeyor:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[![Build status](https://ci.appveyor.com/api/projects/status/kdm6f2xk4s36ytpo?svg=true)](https://ci.appveyor.com/project/newt-sc/a4kScrapers)  
Codefresh:&nbsp;&nbsp;&nbsp;[![Codefresh build status]( https://g.codefresh.io/api/badges/pipeline/newt-sc/a4k-openproject%2Fa4kScrapers%2Fa4kScrapers?branch=master&key=eyJhbGciOiJIUzI1NiJ9.NWM3YWFlOGFhNmQ2MDExNTdmZmM1N2M2.jq7DcvOImjNXgcA-hCGmqo7_TPqgyOe-MyfvLw2DazA&type=cf-2)]( https://g.codefresh.io/pipelines/edit/builds?id=5c883aef34520407784410e2&pipeline=a4kScrapers&projects=a4k-openproject%2Fa4kScrapers&projectId=5cb8380162c2233700023a4d&rightbar=steps&filter=pipeline:5c883aef34520407784410e2~a4kScrapers;branch:master;pageSize:1;timeFrameStart:week)  
CircleCI:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[![CircleCI](https://circleci.com/gh/a4k-openproject/a4kScrapers.svg?style=svg)](https://circleci.com/gh/a4k-openproject/a4kScrapers)  
Github:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[![cron](https://github.com/a4k-openproject/a4kScrapers/actions/workflows/cron.yml/badge.svg)](https://github.com/a4k-openproject/a4kScrapers/actions/workflows/cron.yml)  
Semaphore:&nbsp;&nbsp;[![Build Status](https://newt-sc.semaphoreci.com/badges/a4kScrapers/branches/master.svg)](https://newt-sc.semaphoreci.com/projects/a4kScrapers)  
Wercker:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[![wercker status](https://app.wercker.com/status/3edd14e027f559dac94fc344cfb64733/s/master "wercker status")](https://app.wercker.com/project/byKey/3edd14e027f559dac94fc344cfb64733)  
